<?php
defined('BASEPATH') OR exit("No direct script access allowed");

class Ciscoswitch extends CI_Controller{
 
 
 public function index() {
	 $this->load->driver("session");
	 $this->load->helper("url");
	// print "<pre>";print_r($_POST);
	 
	 $data['connection'] ='';
	 if(!@$_POST['envoyer']){
		 /*Load the form*/
		 $this->load->view("FormTelnet");
	}elseif(@$_POST['ciscocmd']||$_POST['envoyer'])
	{
			 //try to connnect to 
			 if(!$this->session->userdata("ip")){
				 $new_data=array();
		     if($_POST['IP'])$new_data["ip"]=$_POST['IP'];
			 if($_POST['User'])$new_data["user"]=$_POST['User'];
			 if($_POST['Password'])$new_data["pass"]=$_POST['Password'];
			 $this->session->set_userdata($new_data);
			 }
			
			 $ip=$this->session->userdata("ip"); 
			 $pass=$this->session->userdata("pass");
			 $user=$this->session->userdata("user");
			  //print "<pre>";print_r($this->session->userdata);//exit;
			 /* load the cisco libarary*/
			 $params=array("hostname"=>$ip,"password"=>$pass,"username"=>$user,"timeout"=>10); 
			 $this->load->library("Cisco",$params);
			 
			 /*try to connect to host*/
			 $conex=$this->cisco->connect();
			 $data['host']=$ip;
			 
			 if(!$this->cisco->connectionstatus) {
				 // ok connected
			    $data['connction']="connection established to :".$ip;
			    // print "<pre>";print_r($data);exit;
			    if(@!$_POST['ciscocmd'])$ciscocmd='showLogging';
			    else $ciscocmd=$_POST['ciscocmd'];
			    $_extra='';
			    //print "<br>Cmd".$ciscocmd;
			    if(@$_POST['Extra'])$_extra=@$_POST['Extra'];
			    
			    $datos= $this->goAskCisco($ciscocmd,$_extra);
			    //$datos=$this->cisco->$ciscocmd;
			    // show the cmd executed on the user screen
			    $_micmd=$this->cisco->preconfigcmd;/* The list of available cmd*/
			    if(@trim($_extra))
			    $_micmd[$ciscocmd]=str_replace("##extra##",$_extra,$_micmd[$ciscocmd]);
			    
			    $data['cmdexecuted']=$_micmd[$ciscocmd];
			    /*end to show to the user the command choised*/
			    
			    
			    $data['output']=$datos;
			    //print "<pre>";print_r($datos); 
			    
			    
			 }else{
				 //not connected
			 $data['connection']=$this->cisco->connectionstatus;
			 $data['output']=$this->cisco->connectionstatus;
		 
			
		    }
			
			//print "<pre>";print_r($data);
			 $this->load->view("CmdTelnet",$data);
			 
	}
	 
	 }	
	 
	 public function goAskCisco($cmd,$extra){
		 
		 switch($cmd){
			 case "showLogging":
			  $datos=$this->cisco->showLogging();
			  return $this->goformateoLogs($datos);
			 break;
			  case "showInterfacesStatus":
			  $datos=$this->cisco->showInterfacesStatus();
			  //print "<pre>";print_r($datos);exit;
			  return $this->goformateoInterfaceStatus($datos);
			 break;
			 case "showInterface":
			  $datos=$this->cisco->showInterface($extra);
			  return $this->goformateoShowInterface($datos);
			  //print "<pre>";print_r($datos);exit;
			 break;
			 
			 case "showArp":
			  $datos=$this->cisco->showArp();
			  return $this->goformateoShowArp($datos);
			 // print "<pre>";print_r($datos);exit;
			 break;
			 case "showMacAddressTable":
			   $datos =$this->cisco->showMacAddressTable();
			   //print "<pre>";print_r($datos);exit;
			   return $this->goformateoShowMacAddressTable($datos);
			  
			 break;
			 
			 case "ping":
			   $datos =$this->cisco->ping($extra);
			   //print "<pre>";print_r($datos);exit;
			   return $datos;
			   
			   case "traceroute":
			   $datos =$this->cisco->traceroute($extra);
			   //print "<pre>";print_r($datos);exit;
			   return $datos;
			  
			 break;
			 
			 }
		 
		 }
		 
	public function goformateoLogs($datos){
		$_html="<table><tr><td>Time</td><td>Type</td><td>Message</td></tr>";
		foreach($datos as $mi_data){
			$_html.="<tr><td>".$mi_data['timestamp']."</td><td>".$mi_data['type']."</td><td>".$mi_data['message']."</td></tr>";
		}
		$_html.="</table>";
		return $_html;
	}
	
	public function goformateoInterfaceStatus($datos){
		
		$_html="<table><tr><td>Interface</td><td>Description</td><td>Status</td><td>Vlan</td><td>Duplex</td><td>Speed</td><td>Type</td></tr>";
		foreach($datos as $mi_data){
			$_html.="<tr><td>".$mi_data['interface']."</td><td>".$mi_data['description']."</td><td>".$mi_data['status']."</td>
			<td>".$mi_data['vlan']."</td>
			<td>".$mi_data['duplex']."</td>
			<td>".$mi_data['speed']."</td>
			<td>".$mi_data['type']."</td>
			</tr>";
		}
		$_html.="</table>";
		return $_html;
		}
		
		
	public function goformateoShowInterface($datos){
		
		/*To forma the output of an particular interface show interface fa0/13*/
		//print "<br>Total".count($datos);
		$_claves=array_keys($datos);
		//print"<pre>";print_r($_claves);
		$_html="<table>";
		$_data=$datos;
		for($_i=0;$_i<count($_claves);$_i++){
			$_html.="<tr><td>".$_claves[$_i]."</td><td>".$datos[$_claves[$_i]]."</td></tr>";
			}
		$_html.="</table>";
		define("interface","Interface");
	 return $_html;	
	}
	
   public function goformateoShowArp($donnes){
	    //print "<pre>";print_r($donnes);
	    $_html="<table><tr><td>IP address</td><td>MAC Address</td><td>Age</td></tr>";
	    foreach( $donnes as $_miarp){
			 $_html.="<tr><td>".$_miarp['ip']."</td><td>".$_miarp['mac_address']."</td><td>".$_miarp['age']."</td><tr>";
			}
			$_html.="<table>";
	   return $_html;
	   }
	
	public function goformateoShowMacAddressTable($donnes){
		//print "<pre>";print_r($donnes);
		$_html="<table><tr><td>Mac address</td><td>Interface</td></tr>";
		foreach($donnes as $_mimac){
			 $_html.="<table><tr><td>".$_mimac['mac_address']."</td><td>".$_mimac['interface']."</td></tr>";
			}
		$_html.="</table>";
		return $_html;
		}
}
?>
