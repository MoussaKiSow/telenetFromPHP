<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Manage your Cisco router or switch from Internet browser">
    <meta name="author" content="e-smartsolution.co.uk">
<title>Webmanager for Cisco devices, e-smartsolution.co.uk</title>
<meta name="description" 
 content="Connect to your cisco device switch or router by telenet" />
 <meta name="keywords" content="cisco, telnet,learning, cisco, free,online,php,ssh, codeigniter, show,interface,status, access, via,
 php,GUI,user,ccent, ccna" />
<meta content='index, follow' name='robots'/>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta name="author" content="Moussa Ki Sow, e-smartsolution.co.uk"/>
<meta http-equiv="Expires" content="0" />

<link href="<?=base_url()?>exam/css/style.css" rel="stylesheet">
<link rel='stylesheet' id='crafty-social-buttons-styles-css' 
 href='http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/css/public.min.css?ver=1.3.2' type='text/css' media='all' />
<script type="text/javascript">
	
function ActiverConfirm(){ 
	document.getElementById("btnexam1").disabled=false;
	}
	
	
function ConfirmAnswer(){
	//alert(1);
	var yourans= new Array();var j=0;
	for(var i=1;i<=4;i++){
	if(document.getElementById("Reponse"+i).checked){	
		yourans[j]=i;
		j=j+1;	
	}}
		// active the option to confirm anwser
		//alert(yourans);
		var par={"Respuesta":yourans};
		var url='<?=base_url()?>index.php/Praticecomptianetworkn1006ajax';
		$.ajax({
			data:par,
			url:url,
			type:'post',
			beforeSend:function(){
				 $("#PracticeExam").html('<img src="<?=base_url()?>exam/img/loader.gif" class="loadoing">');
				},
			success:function(result){
				//alert("ok");
				$("#PracticeExam").html(result);
				//alert("new question");
				
				document.getElementById('btnexam2').style.display='block';//continue button
				document.getElementById('btnexam1').style.display='none';//confirm an
				}
			});
		
	
	}
	
 function StartPratice(){
	var url='<?=base_url()?>index.php/Praticecomptianetworkn1006ajax';
	var i=eval(document.getElementById("currentprize").value);
	var par={"currentprize":i};
			$.ajax({
		data:par,
		url:url,
		type:'post',
		beforeSend:function(){
		  $("#PracticeExam").html('<img src="<?=base_url()?>exam/img/loader.gif" class="loadoing">');
			},
		success:function(result){
		 document.getElementById("btnexam").style.display="none";
		 document.getElementById("btnexam1").style.display="block";
		 document.getElementById("btnexam1").disabled=true;
		 document.getElementById('btnexam2').style.display='none';//continue button
		 
			$("#PracticeExam").html(result);
			}
		});
  }
  
  function MaReponse(id){
	  document.getElementById("Reponse"+id).checked=true;
	  ActiverConfirm();
	  }
    </script>
    </head>
    <body  oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
        
        <div class="wrapper">
            <header>
	            <div class="e-smartsolution-bar">
		            <a href="http://www.e-smartsolution.co.uk" class="logo" id="logo">
					<img alt="e-smartsolution.co.uk" src="<?=base_url()?>/exam/img/esmartsolution-logo.png" width="250" height="70">
		            </a>
		            
                    <div class="app-name">
                  <h5>Free online, manager for Cisco switch/Router.</h5>
                    </div>
                    
                    
	            </div>
	   
            
	            <div class="app-bar">
<span>Manage your Cisco device: Router or Switch.<br>
<a href="http://www.e-smartsolution.co.uk/comptia220801/" 
 title="Pratice Comptia A+ 220-801" target="_blanck">
	Comptia A+ 220-801</a> |
 <a href="http://www.e-smartsolution.co.uk/comptia220802/" 
 title="Pratice Comptia A+ 220-802" target="_blanck">
	Comptia A+ 220-802</a> |
 <a href="http://www.e-smartsolution.co.uk/comptianetworkn10006/" 
 title="Pratice Comptia Network plus N10-006" target="_blanck">
	Comptia Network+</a>
	|
	
 <a href="http://www.e-smartsolution.co.uk/ccent/" 
 title="Pratice Cisco CCENT, ICND1 v3.0, 100-105 exam questions" target="_blanck">
	CCENT</a>|
	<a href="http://www.e-smartsolution.co.uk/ccna/" 
 title="Pratice Cisco CCNA  exam questions" target="_blanck">
	CCNA</a>|
	
	
 <a href="http://www.e-smartsolution.co.uk" >e-smartsolution</a> |<a href="http://www.e-smartsolution.co.uk/blog" 
 target="_blanck" title="The blog of e-smartsolution.co.uk">Blog</a>|
 <a href="http://www.e-smartsolution.co.uk/contact" title="Contact e-smartsolution team">Contact us</a>   </span>
	            </div><!--//app-bar-->
            </header>
            <section class="main-content">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- CiscoWebemanager -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8270364899437567"
     data-ad-slot="9701397737"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

            <div class="primary">
	  <form action="<?=base_url()?>index.php/Ciscoswitch" method="POST"> 
	    <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control"></label>
			 </div>
			 <div id="resultconnection" ><?=@$connection?></div>
		 
		 </div>
		                  
	 <div class="col-sm-6 col-lg-5" style="background-color: #f2f2fb;">
           <div class="form-group">  
			   <div class="caption" >
			          <label for="title">connected to:: <?=@$host?></label><br>
			         
                   </div>
           
           </div> 
            <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Availabe CMD)</label>
			 </div>
			 <select name="ciscocmd" id="ciscocmd">
			   <option value="showLogging">show logging</option>
 <option value="showInterfacesStatus">show interfaces status</option>
 <option value="trunkInterfaces">show interface status | include trunk</option>
 <option value="showInterface">show interface  </option>
 <option value="availableVlans">show spanning-tree summary | include ^VLAN</option>
 <option value="showArp">show arp | exclude Incomplete</option>
 <option value="showMacAddressTable">show mac address-table | exclude CPU</option>
 <!--<option value="showIpv6Neighbors">show ipv6 neighbors</option>
 <option value="showIpv6Routers">show ipv6 routers</option> -->
 <option value="ping">ping</option>
 <option value="traceroute">traceroute</option>
			 </select>
		 
		 </div>
		 <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Extra</label>
			 </div>
			 <input name="Extra" id="Extra" size="60" value="">
		 
		 </div>
           
           
          
          
		
        
      <div class="form-group">
			   <div class="caption">
				   <label></label>
				     </div>  
	   <input type="submit"  value="Execute" name="envoyer" class="form-control" id="envoyer" >
          </div>    
      		
      		
      		
            <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Output:&nbsp;<?=@$cmdexecuted?></label>
			 </div>
			
		 
		 </div>
		 
	  <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control"></label>
			 </div>
			 <div id="result" ><?=@$output?></div>
		 
		 </div>
            
            
            
		</div> <!-- div col-sm6 col-md-3  -->	
		
	</form>
	<br>
	<b>Keep in mind:</b><br>
 The Telnet should enabled in the remote device.<br>
 Using a PHP class to connect to Cisco IOS devices over Telnet.
	<br>
	<div class="crafty-social-buttons crafty-social-share-buttons crafty-social-buttons-size-2 crafty-social-buttons-align-left crafty-social-buttons-caption-inline-block"><span class="crafty-social-caption">Share this, now:</span><ul class="crafty-social-buttons-list"><li>
						<a target="_blank" title="Share via Facebook" class="crafty-social-button csb-facebook" 
						href="http://www.facebook.com/sharer/sharer.php?u=http://e-smartsolution.co.uk/ciscowebmanager"><img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/facebook.png" alt="Share via Facebook" class="crafty-social-button-image"></a></li>
						<li><a target="_blank" title="Share via Google" class="crafty-social-button csb-google" href="https://plus.google.com/share?url=http://e-smartsolution.co.uk/ciscowebmanager"><img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/google.png" alt="Share via Google" class="crafty-social-button-image"></a></li>
						<li><a target="_blank" title="Share via Twitter" class="crafty-social-button csb-twitter" href="http://twitter.com/share?url=http://e-smartsolution.co.uk/ciscowebmanager/&amp;text=Manage your Cisco router or switch from Internet browser">
							<img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/twitter.png" alt="Share via Twitter" class="crafty-social-button-image"></a></li>
							
							
							<li><a target="_blank" title="Share via linkedin" class="crafty-social-button-image" href="https://www.linkedin.com/shareArticle?mini=true&url=http://e-smartsolution.co.uk/ciscowebmanager/&title=Manage your Cisco router or switch from Internet browser">
							<img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/linkedin.png" alt="Share via linkedin" class="crafty-social-button-image"></a></li>
							
							</ul></div>
		            
                    </div><!--//primary-->
                    
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- ciscowebmanagerfoot -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8270364899437567"
     data-ad-slot="2178130932"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

                </div><!--//page-->
            </section>
            
        </div><!--//wrapper-->
		<footer class="footer ">
		    
            <ul class="footer-links-list copyright">
                <li>© 2015 e-smartsolution</li>
            </ul>
			<div class="footer-bar"></div>
		</footer><!--//footer-->
       
    
 <!-- Core JavaScript Files -->
    <script async src="<?=base_url()?>exam/js/jquery.min.js"></script>
   

    
  <script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-56329108-1', 'auto');
  ga('send', 'pageview');

</script>
    

</body></html>
