<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Practice the Cisco CCENT/CCNA exam questions, Interconnecting Network Devices exam">
    <meta name="author" content="e-smartsolution.co.uk">
<title>Practice cisco CCENT/CCNA exams questions for free&online, e-smartsolution.co.uk</title>
<meta name="description" 
 content="Practice test for Cisco CCENT/CCNA candidates preparing for exams.cisco Certified Entry Networking Technician,A CCENT is your first step toward CCNA certification and will help you stand out from the crowd in entry-level positions" />
 <meta name="keywords" content="ICND, 100-105, CCNA, version 3.0, Interconnecting,Network. Devices,free, online,version, V3.0. v30, CCENT,switch, router, certification, hub, repeater, english, test, practise, practice, bridge, CDP, MAC, IPv4, IPv6, subneting, CIDER,show, version,interface, vlan,neighbors, detail, encasuplation, dot1q,routing, table, IP, protocols, route, AD, administration, distance,get,certificate,jobs,IT,learning, cisco, free,online" />
<meta content='index, follow' name='robots'/>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />

<link href="<?=base_url()?>exam/css/style.css" rel="stylesheet">
<link rel='stylesheet' id='crafty-social-buttons-styles-css' 
 href='http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/css/public.min.css?ver=1.3.2' type='text/css' media='all' />
<script type="text/javascript">
	
function ActiverConfirm(){ 
	document.getElementById("btnexam1").disabled=false;
	}
	
	
function ConfirmAnswer(){
	//alert(1);
	var yourans= new Array();var j=0;
	for(var i=1;i<=4;i++){
	if(document.getElementById("Reponse"+i).checked){	
		yourans[j]=i;
		j=j+1;	
	}}
		// active the option to confirm anwser
		//alert(yourans);
		var par={"Respuesta":yourans};
		var url='<?=base_url()?>index.php/Praticecomptianetworkn1006ajax';
		$.ajax({
			data:par,
			url:url,
			type:'post',
			beforeSend:function(){
				 $("#PracticeExam").html('<img src="<?=base_url()?>exam/img/loader.gif" class="loadoing">');
				},
			success:function(result){
				//alert("ok");
				$("#PracticeExam").html(result);
				//alert("new question");
				
				document.getElementById('btnexam2').style.display='block';//continue button
				document.getElementById('btnexam1').style.display='none';//confirm an
				}
			});
		
	
	}
	
 function StartPratice(){
	var url='<?=base_url()?>index.php/Praticecomptianetworkn1006ajax';
	var i=eval(document.getElementById("currentprize").value);
	var par={"currentprize":i};
			$.ajax({
		data:par,
		url:url,
		type:'post',
		beforeSend:function(){
		  $("#PracticeExam").html('<img src="<?=base_url()?>exam/img/loader.gif" class="loadoing">');
			},
		success:function(result){
		 document.getElementById("btnexam").style.display="none";
		 document.getElementById("btnexam1").style.display="block";
		 document.getElementById("btnexam1").disabled=true;
		 document.getElementById('btnexam2').style.display='none';//continue button
		 
			$("#PracticeExam").html(result);
			}
		});
  }
  
  function MaReponse(id){
	  document.getElementById("Reponse"+id).checked=true;
	  ActiverConfirm();
	  }
    </script>
    </head>
    <body  oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
        
        <div class="wrapper">
            <header>
	            <div class="e-smartsolution-bar">
		            <a href="http://www.e-smartsolution.co.uk" class="logo" id="logo">
					<img alt="e-smartsolution.co.uk" src="<?=base_url()?>/exam/img/esmartsolution-logo.png" width="250" height="70">
		            </a>
		            
                    <div class="app-name">
                  <h5>Free online, practice test for Cisco CCENT/CCNA candidates preparing for exams.</h5>
                    </div>
                    
                    
	            </div>
	   
            
	            <div class="app-bar">
<span>The Cisco, ICND1 v3.0 is the latest iteration (at the time of this writing) for one of the most famous professional certification exams on the planet.<br>
<a href="http://www.e-smartsolution.co.uk/comptia220801/" 
 title="Pratice Comptia A+ 220-801" target="_blanck">
	Comptia A+ 220-801</a> |
 <a href="http://www.e-smartsolution.co.uk/comptia220802/" 
 title="Pratice Comptia A+ 220-802" target="_blanck">
	Comptia A+ 220-802</a> |
 <a href="http://www.e-smartsolution.co.uk/comptianetworkn10006/" 
 title="Pratice Comptia Network plus N10-006" target="_blanck">
	Comptia Network+</a>
	|
	
 <a href="http://www.e-smartsolution.co.uk/ccent/" 
 title="Pratice Cisco CCENT, ICND1 v3.0, 100-105 exam questions" target="_blanck">
	CCENT</a>|
	<a href="http://www.e-smartsolution.co.uk/ccna/" 
 title="Pratice Cisco CCNA  exam questions" target="_blanck">
	CCNA</a>|
	
	
 <a href="http://www.e-smartsolution.co.uk" >e-smartsolution</a> |<a href="http://www.e-smartsolution.co.uk/blog" 
 target="_blanck" title="The blog of e-smartsolution.co.uk">Blog</a>|
 <a href="http://www.e-smartsolution.co.uk/contact" title="Contact e-smartsolution team">Contact us</a>   </span>
	            </div><!--//app-bar-->
            </header>
            <section class="main-content">

                <div class="page">
					<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Comptia220801 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8270364899437567"
     data-ad-slot="3996032533"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

            <div class="primary">
	  <form action="<?=base_url()?>index.php/praticecomptia220801ajax" method="POST">                  
	<div class="exam" id="PracticeExam">
        <h5><?= $question?> </h5>
        <div class="rules-box">
            <ul class="rules-list">
                <li class="rule-item ">
                <?=$ans1?>
                </li>
                <li class="rule-item">
                <?=$ans2?>
                </li>
                 <li class="rule-item">
                <?=$note?>
                </li>
                 <li class="rule-item">
                <?=$rules?>
                </li>
            </ul>
        </div>
       
        </div>
		<!--//rules-box-->
		<input type="hidden" name="currentprize" id="currentprize" value='1'>
		<input type="button" value="Begin Test" onClick="javascript:StartPratice();" class="start-exam" id="btnexam">
		<input type="button" value="Done" onClick="javascript:ConfirmAnswer();" class="confirm-your" id="btnexam1" disabled>
		<input type="button" value="Continue" onClick="javascript:StartPratice();" class="continue-exam" id="btnexam2">
		
	</form>
	<br>
	<b>Keep in mind:</b><br>
 Multiple Choice (single and multiple answer), Drag-and-Drop, Simulations, Simlets, and Testlets
	<br>
	<div class="crafty-social-buttons crafty-social-share-buttons crafty-social-buttons-size-2 crafty-social-buttons-align-left crafty-social-buttons-caption-inline-block"><span class="crafty-social-caption">Share this, now:</span><ul class="crafty-social-buttons-list"><li>
						<a target="_blank" title="Share via Facebook" class="crafty-social-button csb-facebook" 
						href="http://www.facebook.com/sharer/sharer.php?u=http://e-smartsolution.co.uk/ccent"><img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/facebook.png" alt="Share via Facebook" class="crafty-social-button-image"></a></li>
						<li><a target="_blank" title="Share via Google" class="crafty-social-button csb-google" href="https://plus.google.com/share?url=http://e-smartsolution.co.uk/ccent"><img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/google.png" alt="Share via Google" class="crafty-social-button-image"></a></li>
						<li><a target="_blank" title="Share via Twitter" class="crafty-social-button csb-twitter" href="http://twitter.com/share?url=http://e-smartsolution.co.uk/ccent/&amp;text=Practice the Cisco CCENT, ICND1 v3.0(100-105) exam">
							<img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/twitter.png" alt="Share via Twitter" class="crafty-social-button-image"></a></li></ul></div>
		            
                    </div><!--//primary-->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Comptia202801body -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8270364899437567"
     data-ad-slot="5472765734"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                </div><!--//page-->
            </section>
            
        </div><!--//wrapper-->
		<footer class="footer ">
		    
            <ul class="footer-links-list copyright">
                <li>© 2015 e-smartsolution</li>
            </ul>
			<div class="footer-bar"></div>
		</footer><!--//footer-->
       
    
 <!-- Core JavaScript Files -->
    <script async src="<?=base_url()?>exam/js/jquery.min.js"></script>
   

    
  <script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-56329108-1', 'auto');
  ga('send', 'pageview');

</script>
    

</body></html>
