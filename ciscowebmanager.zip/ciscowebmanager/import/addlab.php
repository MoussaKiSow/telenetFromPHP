<html>
<head>
<title>
Add question and anwser</title>
<meta name="robots" content="noindex, nofollow">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container" >
		<div class="row" >
<?php

define('DB_HOST','localhost');
define('DB_USER','esmartso_Us0120');
define('DB_PASSWORD','Ubd€b@1986');
define('DB_NAME','esmartso_01102010');



error_reporting(E_ERROR);	
$conex= new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
   if($conex->connect_error){
	   die('Error connection DB1 ');
	   }
if(@$_POST['envoyer']){
	
//print "<pre>";print_r($_POST);	   
	
	
		$lab=$_POST['Lab'];
		$title=$_POST['Title'];
		$url=makeurlformtitle1($title);
		$date_=date('Y-m-d H:i:s');
			$lab=mysqli_real_escape_string($conex,$lab);
			 $title_=mysqli_real_escape_string($conex,$title);
 
	   $_inq="insert into ESb_posts(post_author,post_date,post_date_gmt,post_content, post_title,post_name,id_question) 
	   values(443,'".$date_."','".$date_."','".$lab."','".$title_."','".$url."',0)";
	  
	   
		//print "<br><br>".$_inq;exit;
		
		if($rs9=$conex->query($_inq))
		{
				$id_post=mysqli_insert_id($conex);
				print "<br>Inserting post".$id_post." url..".$url;
				if($id_post){
			//relations
			//$term_taxnomy_id=array(143,144,145,147,198,199);
			//$term_taxnomy_id=array(143,147,198,200,311,358,313,314,315,316,317,318);
			//$term_taxnomy_id=array(143,147,198,200,359,360,361,362,363,364,365,366,367);
			//$term_taxnomy_id=array(143,147,407,408,409,410,411,412, 416);
			$term_taxnomy_id=array(489,501,502,520,521,522);
		   foreach($term_taxnomy_id as $id_rela){
			$in_="insert into ESb_term_relationships(object_id,term_taxonomy_id) VALUES(".$id_post.",".$id_rela.")";
			if($rsla=$conex->query($in_)) print "<br>Inserted id_post ".$id_post." and category ".$id_rela;
			}
			
		}}
		
		


		
		
}else{

?>


			<form  method="post" name="process" id="process" class="horizontal-form" role="form">
          
			   	  <div class="col-sm-6 col-lg-5" style="background-color: #f2f2fb;">
           <div class="form-group">  
			   <div class="caption" >
			          <label for="title">Add command to blog</label><br>
			         
                   </div>
           
           </div> 
            <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Title</label>
			 </div>
			 <input name="Title" id="Title" size="60">
		 
		 </div>
           
	   
              <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Lab command</label>
			 </div>
			 <input type="hidden" name="Code" id="Code" value="<?php echo $id_question;?>">
			 <textarea name="Lab" id="Lab" rows=6  cols=60></textarea>
		 
		 </div>
		
          
          
		
        
      <div class="form-group">
			   <div class="caption">
				   <label>Add to blog</label>
				     </div>  
	   <input type="submit"  value="Save" name="envoyer" class="form-control" id="envoyer" >
             </div>    
      		
		</div> <!-- div col-sm6 col-md-3  -->	
		</form>
		
             
        
  
	<?php }
	
	
function makeurlformtitle1($unformatted) {

    $url = strtolower(trim($unformatted));

    //replace accent characters, forien languages
    $search = array("'",'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ'); 
    $replace = array('','A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o'); 
    $url = str_replace($search, $replace, $url);

    //replace common characters
    $search = array('&', '£', '$','€'); 
    $replace = array('and', 'pounds', 'dollars','euro'); 
    $url= str_replace($search, $replace, $url);

    // remove - for spaces and union characters
    $find = array(' ', '&', '\r\n', '\n', '+', ',', '//');
    $url = str_replace($find, '-', $url);

    //delete and replace rest of special chars
    $find = array('/[^a-z0-9\-<>]/', '/[\-]+/', '/<[^>]*>/');
    $replace = array('', '-', '');
    $uri = preg_replace($find, $replace, $url);

    return $uri;
}
// print $_inq.";";


	
	?>			
 </div> <!-- row -->
	</div><!--container -->
		
    </section>


</body>
</html>
