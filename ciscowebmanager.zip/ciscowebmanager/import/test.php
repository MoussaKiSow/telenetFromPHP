<?php

print "ii<pre>";print_r($_SERVER['HTTP_HOST']);
$_mi_url="http://".$_SERVER['HTTP_HOST'];
print $_mi_url;
?>
