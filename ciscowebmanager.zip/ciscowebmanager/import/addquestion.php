<html>
<head>
<title>
Add question and anwser</title>
<meta name="robots" content="noindex, nofollow">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container" >
		<div class="row" >
<?php

define('DB_HOST','localhost');
define('DB_USER','esmartso_Us0120');
define('DB_PASSWORD','Ubd€b@1986');
define('DB_NAME','esmartso_01102010');



error_reporting(E_ERROR);	
$conex= new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
   if($conex->connect_error){
	   die('Error connection DB1 ');
	   }
if(@$_POST['envoyer']){
	
//print "<pre>";print_r($_POST);	   
	
	
		$id=getQuestionId();
		$question=$_POST['Question'];
		$type=$_POST['Type'];
		$respuesta=$_POST['possibleanwsers'];
		$okrespuesta=$_POST['correctanwsers'];
		$_resp=explode("ok",$okrespuesta);
		
		$notes=$_POST['Notes'];
		$ok_respuesta=gotInsertRespuesta($respuesta,$_resp,$id,$notes);
		//die("ok_respuesta".$ok_respuesta);
		if($ok_respuesta>=4){
			$_var[0]=$id;
			$_var[1]=mysqli_real_escape_string($conex,$question);
			$_var[3]=$type;
			
		 // create a user
		 $_in="INSERT INTO Questionsccent(Code,Description,Type) VALUES('".join("','",$_var)."')";
		//print "<br>".$_in;//die("Question");
		 if($conex->query($_in)){
			 echo "<br>Questions and answers add => ID is: ".$id.'<br>Got create post.<a href="http://e-smartsolution.co.uk/ccent/import/goexportwordpress.php" target="_blanck">Generate posts</a>'; 
			 }
		}else echo "<br>Not question id<br>Error inserting that:<br>".$_in;
		
		
		
		


		
		
}else{
	
	
	
	

$id_question=getQuestionId();


?>


			<form  method="post" name="process" id="process" class="horizontal-form" role="form">
          
			   	  <div class="col-sm-6 col-lg-5" style="background-color: #f2f2fb;">
           <div class="form-group">  
			   <div class="caption" >
			          <label for="title">Add Question</label><br>
			         
                   </div>
           
           </div> 
	   
              <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Question</label>
			 </div>
			 <input type="hidden" name="Code" id="Code" value="<?php echo $id_question;?>">
			 <textarea name="Question" id="Question" rows=6  cols=60></textarea>
		 
		 </div>
		
          
           <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Possible anwsers:<br>Put anwsers by "skf"</label>
			 </div>
			 <textarea name="possibleanwsers" id="possibleanwsers" rows=6 cols=60></textarea>
		 
		 </div>
            <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Correct anwsers:<br>Put anwsers by "1ok or 2ok 3ok"</label>
			 </div>
			 <textarea name="correctanwsers" id="correctanwsers" rows=6 cols=60></textarea>
		 
		 </div>
		 
           <div class="form-group">
			   <div class="caption">
           <label for="Type" class="label-control"></label>Type
           </div>
          <select id="Type"  name="Type" >  
			  <option value="1" selected>One correct</option>
			  <option value="2">Multiple correct</option>
			  </select>
			  
		</div>
		
		   <div class="form-group">
			 <div class="caption">
			 <label for="Question" class="label-control">Notes</label>
			 </div>
			 <textarea name="Notes" id="Notes" rows=6 cols=60></textarea>
		 
		 </div>
        
      <div class="form-group">
			   <div class="caption">
				   <label>Confirmation</label>
				     </div>  
	   <input type="submit"  value="Save" name="envoyer" class="form-control" id="envoyer" >
             </div>    
      		
		</div> <!-- div col-sm6 col-md-3  -->	
		</form>
		
             
        
  
	<?php }
	
	
	 function getQuestionId()
	{
		global $conex;
		$_sql="SELECT Id FROM Questionsccent ORDER BY Id DESC LIMIT 0,1";
$query=$conex->query($_sql);
$_select='<select name="ToBeRating" id="ToBeRating" ><option value=""></option>';

if($row=$query->fetch_row()){

	$id=$row[0]+1;//die($id);
	}
	
	return $id;
}

	function gotInsertRespuesta($respuesta,$ok,$idquestion,$notes){
		global $conex;
		$okinsert=1;
		//print "Respuesta".$resputa;
		
		if(count($ok)<1)die("<br>I need at least one correct answer!");
		
		$sep=explode("skf",$respuesta);
		/*print "Answers:<pre>";print_r($sep);
		print "good answers:<pre>";print_r($ok);
		print "<br>Lista de respuesta:".count($sep);*/
		if(count($sep)>=4){
			
		for($i=0;$i<count($sep);$i++ )
		{ 
			$mirespuesta=str_replace (array("\r\n", "\n", "\r"),'', $sep[$i]);//remove return,
			$_var[0]=$idquestion;
		  $_var[1]=mysqli_real_escape_string($conex,$mirespuesta);
		  
		  $numrep=$i+1;//array cuenta desde 0, la respuesta 1,2,3,4..
		  $_var[2]=$numrep;
		  if(in_array($numrep,$ok)){
		    $_var[3]=1; //ok_answer is 1
		    $_var[4]=mysqli_real_escape_string($conex,$notes);// only add notes once,
		    $notes='';
		    
	    	}
		  else {
			  $_var[3]=0;
			  $_var[4]='';
			  }
		  
		 // print "<pre>";print_r($_var);
		  $_in="INSERT INTO QuestionsAnswersccent(id_question, Answer, id_answer, Ok_answer, Notes) VALUES('".join("','",$_var)."')";
		  //print "<br>".$_in;
		   
		   if($conex->query($_in)){
			   print "<br>Ok answer ".$numrep;
		   $okinsert++;
			}else
			 print "Error inserting that...<br>".$_in;
			$numrep='';
				
		}	 //end for
			
		}else die("<br>I need at least 4 possible answers".count($sep));
		 return $okinsert;
		
		}
	
	?>			
 </div> <!-- row -->
	</div><!--container -->
		
    </section>


</body>
</html>
