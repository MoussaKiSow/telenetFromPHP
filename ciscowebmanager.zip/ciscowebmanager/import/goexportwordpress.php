<?php
error_reporting(E_ERROR);
/*
 $db_server = '213.171.200.78';
     $db_user   = 'Cod2017Ui';
    $db_pass   = 'IO45&Y23&es';
    $db_name   = 'SelEna1986';
   */
   
$config_dbhost="localhost"; # Direccion de la maquina donde esta la BD
$config_dbname="esmartso_01102010"; # Nombre de la BD
$config_dbuser="esmartso_Us0120"; # Usuario de acceso a la BD
$config_dbpass="Ubd€b@1986"; # Password de acceso a la BD

    $conex= new mysqli($config_dbhost,$config_dbuser,$config_dbpass,$config_dbname);
   if($conex->connect_error){
	   die('Error connection DB1 ');
	   }

//print "<pre>";print_r($conex);
$_sql="SELECT Code, Description FROM Questionsccent WHERE ";
if($_GET['code'])
$_sql.="  Code='".$_GET['code']."'";
elseif($_GET['all'])
$_sql.=" status_mobile=01";
else $_sql.="Url is null or Url=''";
$_sql.="ORDER BY Id ASC";
//print "<br>".$_sql;//exit;
$rs=$conex->query($_sql);
//print "<pre>";print_r($rs);exit;
while($var=$rs->fetch_row()){
	$des=$var[1];
	$quest=htmlentities($des);
	
	$title=$des;
	if(strlen($des)>180)
	$title_=substr($title,0,180);
	else 
	$title_=$title;
	
	$url=makeurlformtitle1($title_);
	$code=$var[0];
	
	$_sql1="SELECT Answer,Ok_answer,Notes FROM QuestionsAnswersccent WHERE id_question='".$code."'";
	//print "<br>".$_sql1;
	 $rs1=$conex->query($_sql1);
	 $ok_ans='';$totalnotes='';$i=1;
	 while($var2=$rs1->fetch_row()){
		 $ok=$var2[1];
		 $answer=$var2[0];
		 $notes=$var2[2];
		 
		 if($ok==1){
		 $ok_ans.='<li class="correct"><b> '.$i.'-&nbsp;'.$answer.'&nbsp;</b></li>';	
		 if($notes)$totalnotes.='<br>'.$notes;
		 }
		
		 $quest.='<li> '.$i.'-&nbsp;'.$answer.'</li>';		
		 $i++;
		 }
		 $quest.='<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Comptia220801 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8270364899437567"
     data-ad-slot="3996032533"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script><li class="correct"><h3>The correct answer is:</h3></li>'.$ok_ans.$totalnotes.'.
<br>Practice Cisco ICND1 v3.0(100-105) exam or IT skills <a href="http://www.e-smartsolution.co.uk/ccent/" 
 title="Practice Cisco ICND1 v3.0(100-105)  exam" >
	Practice Cisco ICND1 v3.0(100-105) </a> ';

	
  
  
 ///$url=substr(makeurlformtitle1($title),0,100);
 $date_=date('Y-m-d H:i:s');
 //print "<br>Url".$url;
  $quest_=mysqli_real_escape_string($conex,$quest);
  $title_=mysqli_real_escape_string($conex,$title);
 
   $_inq="insert into ESb_posts(post_author,post_date,post_date_gmt,post_content, post_title,post_name,id_question) 
   values(1,'".$date_."','".$date_."','".$quest_."','".$title_."','".$url."',".$code.")";
  
   
	//print "<br><br>".$_inq;exit;
	
	if($rs9=$conex->query($_inq))
	{
			$id_post=mysqli_insert_id($conex);
			print "<br>Inserting post".$id_post." Code question..".$code;
			if($id_post){
			//relations
			//$term_taxnomy_id=array(143,144,145,147,198,199);
			//$term_taxnomy_id=array(143,147,198,200,311,358,313,314,315,316,317,318);
			//$term_taxnomy_id=array(143,147,198,200,359,360,361,362,363,364,365,366,367);
			//$term_taxnomy_id=array(143,147,407,408,409,410,411,412, 416);
			$term_taxnomy_id=array(138,468,469,489,501,502,503,504,505,506);
		   foreach($term_taxnomy_id as $id_rela){
			$in_="insert into ESb_term_relationships(object_id,term_taxonomy_id) VALUES(".$id_post.",".$id_rela.")";
			if($rsla=$conex->query($in_)) print "<br>Inserted id_post ".$id_post." and category ".$id_rela;
			}
			
			$up="UPDATE Questionsccent SET Url='http://www.e-smartsolution.co.uk/blog/".$url."' WHERE Code=".$code."";
			//print "<br>Update ".$up;
			if($rs_up=$conex->query($up)) print "<br>Updated url on the table Questionsccent Code".$code;
			else print "<br>Error".$up;
			//exit;
		  }		
 //die("Ok");
 } // ok insert
} // bucle by question


function makeurlformtitle1($unformatted) {

    $url = strtolower(trim($unformatted));

    //replace accent characters, forien languages
    $search = array("'",'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ'); 
    $replace = array('','A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o'); 
    $url = str_replace($search, $replace, $url);

    //replace common characters
    $search = array('&', '£', '$','€'); 
    $replace = array('and', 'pounds', 'dollars','euro'); 
    $url= str_replace($search, $replace, $url);

    // remove - for spaces and union characters
    $find = array(' ', '&', '\r\n', '\n', '+', ',', '//');
    $url = str_replace($find, '-', $url);

    //delete and replace rest of special chars
    $find = array('/[^a-z0-9\-<>]/', '/[\-]+/', '/<[^>]*>/');
    $replace = array('', '-', '');
    $uri = preg_replace($find, $replace, $url);

    return $uri;
}
// print $_inq.";";


?>
